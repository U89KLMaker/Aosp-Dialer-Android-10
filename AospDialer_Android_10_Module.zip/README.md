##########################################################

#######################
# AospDialer ║ Android 10
#######################

#####################
## Creator :: U89KLMaker
#####################

## Supporting links -
#export Telegram="https://t.me/"
-- https://t.me/Aosp_dialer
-- https://t.me/call_recording_dialer_app 

## Credits -
-- lineageOS.

## Requirements -
-- Just need Android 10 devices.

## Notes -
-- Dialer from lineageos and dotos and crdroid.
-- This module only supports Android 10 devices.

## Changelog -
-- nothing.

## Donate -
-- nothing.

## Credit - 
-- @topjohnwu 

## The Date & Time module was developed. -
-- 2021/10/8 2:43:49 GMT+5:30

##########################################################